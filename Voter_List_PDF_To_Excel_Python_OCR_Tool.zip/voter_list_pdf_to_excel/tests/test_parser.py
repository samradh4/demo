import unittest
from pathlib import Path
import tempfile
import zipfile

from voter_ocr import OCRConfig, VoterRecord, deduplicate_records, export_to_excel, parse_voter_record


class ParserTests(unittest.TestCase):
    def test_hindi_record(self):
        text = """
        125 ABC1234567
        नाम: सीमा देवी
        पति का नाम: राजेश कुमार
        मकान संख्या: 42-A
        आयु: 36 लिंग: महिला
        """
        record = parse_voter_record(text, 82.5, "sample.pdf", 2, 1)
        self.assertEqual(record.serial_number, "125")
        self.assertEqual(record.epic_id, "ABC1234567")
        self.assertEqual(record.voter_name, "सीमा देवी")
        self.assertEqual(record.relative_name, "राजेश कुमार")
        self.assertEqual(record.relation_type, "Husband / पति")
        self.assertEqual(record.house_number, "42-A")
        self.assertEqual(record.age, "36")
        self.assertEqual(record.gender, "Female / महिला")
        self.assertFalse(record.review_needed)

    def test_english_record_with_epic_ocr_correction(self):
        text = """
        77 ABCl234567
        Name: Rohan Mehta
        Father's Name: Suresh Mehta
        House No: 18/2
        Age: 24 Gender: Male
        """
        record = parse_voter_record(text, 75.0, "sample.pdf", 1, 1)
        self.assertEqual(record.epic_id, "ABC1234567")
        self.assertEqual(record.voter_name, "Rohan Mehta")
        self.assertEqual(record.age, "24")
        self.assertEqual(record.gender, "Male / पुरुष")



    def test_devanagari_digits_are_normalized(self):
        text = """
        १२५ ABC1234567
        नाम: सीमा देवी
        पिता का नाम: मोहन लाल
        मकान संख्या: ४२
        आयु: ३६ लिंग: महिला
        """
        record = parse_voter_record(text, 80.0, "sample.pdf", 1, 1)
        self.assertEqual(record.serial_number, "125")
        self.assertEqual(record.house_number, "42")
        self.assertEqual(record.age, "36")

    def test_duplicate_epic_rows_are_preserved_and_flagged(self):
        first = VoterRecord(source_file="a.pdf", page_number=1, card_number=1, epic_id="ABC1234567", voter_name="One", age="25", gender="Male / पुरुष", ocr_confidence=90, review_needed=False)
        second = VoterRecord(source_file="a.pdf", page_number=1, card_number=2, epic_id="ABC1234567", voter_name="Two", age="26", gender="Female / महिला", ocr_confidence=88, review_needed=False)
        output = deduplicate_records([first, second])
        self.assertEqual(len(output), 2)
        self.assertTrue(all(item.review_needed for item in output))
        self.assertTrue(all("Duplicate EPIC ID" in item.review_issues for item in output))

    def test_excel_export_is_valid_zip(self):
        record = VoterRecord(
            source_file="sample.pdf",
            page_number=1,
            card_number=1,
            serial_number="1",
            epic_id="ABC1234567",
            voter_name="Test User",
            age="25",
            gender="Male / पुरुष",
            ocr_confidence=90.0,
            review_needed=False,
            raw_ocr_text="Name: Test User",
        )
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "output.xlsx"
            export_to_excel([record], path, OCRConfig(), total_pages=1)
            self.assertTrue(path.exists())
            self.assertTrue(zipfile.is_zipfile(path))


if __name__ == "__main__":
    unittest.main()
