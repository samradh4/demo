#!/usr/bin/env python3
"""Core OCR and Excel export logic for voter-list PDFs and images.

The extractor is intentionally conservative: every row keeps its raw OCR text,
confidence score, and review flags so that uncertain records are not silently
accepted as correct.
"""

from __future__ import annotations

import argparse
import io
import math
import re
import shutil
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Iterator, Optional, Sequence, Union

import cv2
import fitz  # PyMuPDF
import numpy as np
import pytesseract
import xlsxwriter
from PIL import Image, ImageOps, ImageSequence
from pytesseract import Output

ProgressCallback = Callable[[int, int, str], None]


@dataclass
class OCRConfig:
    dpi: int = 250
    language: str = "hin+eng"
    psm: int = 6
    min_confidence: float = 35.0
    detect_cards: bool = True
    skip_first_pages: int = 0
    max_pages: Optional[int] = None
    trim_top_percent: float = 0.07
    trim_bottom_percent: float = 0.03
    min_card_count: int = 4


@dataclass
class VoterRecord:
    source_file: str = ""
    page_number: int = 0
    card_number: int = 0
    serial_number: str = ""
    epic_id: str = ""
    voter_name: str = ""
    relative_name: str = ""
    relation_type: str = ""
    house_number: str = ""
    age: str = ""
    gender: str = ""
    ocr_confidence: float = 0.0
    review_needed: bool = True
    review_issues: str = ""
    raw_ocr_text: str = ""


FIELD_LABELS = {
    "name": [
        "निर्वाचक का नाम",
        "मतदाता का नाम",
        "नाम",
        "elector name",
        "voter name",
        "name",
    ],
    "father": ["पिता का नाम", "पिता", "father's name", "father name"],
    "husband": ["पति का नाम", "पति", "husband's name", "husband name"],
    "mother": ["माता का नाम", "माता", "mother's name", "mother name"],
    "other": ["अन्य का नाम", "guardian name", "relative name"],
    "house": [
        "मकान संख्या",
        "मकान नं",
        "गृह संख्या",
        "घर संख्या",
        "house number",
        "house no",
    ],
    "age": ["आयु", "उम्र", "age"],
    "gender": ["लिंग", "gender", "sex"],
}

ALL_STOP_LABELS = sorted(
    {label for values in FIELD_LABELS.values() for label in values},
    key=len,
    reverse=True,
)

EPIC_RE = re.compile(r"\b[A-Z]{3}[0-9]{7}\b")
LOOSE_EPIC_RE = re.compile(r"\b[A-Z0-9]{9,12}\b")


def verify_tesseract(language: str = "hin+eng") -> tuple[bool, str]:
    """Check whether Tesseract and the requested language packs are available."""
    exe = shutil.which("tesseract")
    if not exe:
        return False, "Tesseract OCR was not found in PATH."
    try:
        available = set(pytesseract.get_languages(config=""))
    except Exception as exc:  # pragma: no cover - platform-specific
        return False, f"Tesseract is installed but could not be queried: {exc}"
    requested = {part.strip() for part in language.split("+") if part.strip()}
    missing = sorted(requested - available)
    if missing:
        return False, f"Missing Tesseract language pack(s): {', '.join(missing)}"
    return True, exe


def normalize_text(text: str) -> str:
    text = text.replace("\u00ad", "").replace("\u200c", "").replace("\u200d", "")
    text = text.translate(str.maketrans("०१२३४५६७८९", "0123456789"))
    text = text.replace("।", "|")
    text = re.sub(r"[\t\r]+", " ", text)
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def clean_value(value: str) -> str:
    value = normalize_text(value)
    value = re.sub(r"^[\s:;|\-–—.,]+", "", value)
    value = re.sub(r"[\s:;|\-–—.,]+$", "", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def _label_pattern(labels: Sequence[str]) -> str:
    return "|".join(re.escape(x) for x in sorted(labels, key=len, reverse=True))


def extract_labeled_value(text: str, labels: Sequence[str]) -> str:
    """Extract a field after a Hindi/English label, stopping at another label."""
    label_pat = _label_pattern(labels)
    stop_pat = _label_pattern(ALL_STOP_LABELS)
    pattern = re.compile(
        rf"(?:^|\n|\|)\s*(?:{label_pat})\s*[:\-–—|]?\s*(.*?)"
        rf"(?=\n\s*(?:{stop_pat})\s*[:\-–—|]?|\||$)",
        flags=re.IGNORECASE | re.DOTALL,
    )
    match = pattern.search(text)
    if not match:
        # Fallback for OCR output where several fields were merged onto one line.
        pattern_inline = re.compile(
            rf"(?:{label_pat})\s*[:\-–—|]?\s*(.*?)"
            rf"(?=\s+(?:{stop_pat})\s*[:\-–—|]?|$)",
            flags=re.IGNORECASE,
        )
        match = pattern_inline.search(text)
    return clean_value(match.group(1)) if match else ""


def normalize_epic_candidate(candidate: str) -> str:
    candidate = re.sub(r"[^A-Za-z0-9]", "", candidate).upper()
    if len(candidate) != 10:
        return ""
    prefix_map = str.maketrans({"0": "O", "1": "I", "5": "S", "8": "B", "2": "Z", "6": "G"})
    number_map = str.maketrans({"O": "0", "Q": "0", "D": "0", "I": "1", "L": "1", "S": "5", "B": "8", "Z": "2", "G": "6"})
    prefix = candidate[:3].translate(prefix_map)
    suffix = candidate[3:].translate(number_map)
    normalized = prefix + suffix
    return normalized if EPIC_RE.fullmatch(normalized) else ""


def extract_epic_id(text: str) -> str:
    uppercase = text.upper()
    direct = EPIC_RE.search(uppercase)
    if direct:
        return direct.group(0)

    # OCR may insert spaces or punctuation inside the EPIC number.
    for line in uppercase.splitlines():
        compact = re.sub(r"[^A-Z0-9]", "", line)
        for width in (10, 11, 12):
            for i in range(0, max(0, len(compact) - width + 1)):
                normalized = normalize_epic_candidate(compact[i : i + width])
                if normalized:
                    return normalized

    for candidate in LOOSE_EPIC_RE.findall(uppercase):
        normalized = normalize_epic_candidate(candidate)
        if normalized:
            return normalized
    return ""


def extract_serial_number(text: str) -> str:
    lines = [clean_value(line) for line in text.splitlines() if clean_value(line)]
    for line in lines[:4]:
        match = re.match(r"^(?:क्रम\s*(?:संख्या|सं)?\s*[:\-]?)?\s*(\d{1,5})\b", line, re.IGNORECASE)
        if match:
            return match.group(1)
    match = re.search(r"(?:serial\s*(?:no|number)?|क्रम\s*(?:संख्या|सं)?)\s*[:\-]?\s*(\d{1,5})", text, re.IGNORECASE)
    return match.group(1) if match else ""


def extract_age(text: str) -> str:
    label_pat = _label_pattern(FIELD_LABELS["age"])
    match = re.search(rf"(?:{label_pat})\s*[:\-–—|]?\s*([0-9OIl]{{1,3}})", text, re.IGNORECASE)
    if not match:
        return ""
    raw = match.group(1).upper().translate(str.maketrans({"O": "0", "I": "1", "L": "1"}))
    try:
        age = int(raw)
    except ValueError:
        return ""
    return str(age) if 18 <= age <= 125 else ""


def extract_gender(text: str) -> str:
    label_pat = _label_pattern(FIELD_LABELS["gender"])
    match = re.search(
        rf"(?:{label_pat})\s*[:\-–—|]?\s*(पुरुष|महिला|स्त्री|तृतीय\s*लिंग|अन्य|male|female|other|m|f)(?=\s|[|,;.]|$)",
        text,
        re.IGNORECASE,
    )
    if not match:
        return ""
    value = match.group(1).strip().lower()
    if value in {"पुरुष", "male", "m"}:
        return "Male / पुरुष"
    if value in {"महिला", "स्त्री", "female", "f"}:
        return "Female / महिला"
    return "Other / अन्य"


def apply_review_flags(record: VoterRecord, min_confidence: float = 35.0) -> VoterRecord:
    issues: list[str] = []
    if not record.epic_id:
        issues.append("Missing/unclear EPIC ID")
    if not record.voter_name:
        issues.append("Missing/unclear voter name")
    if not record.age:
        issues.append("Missing/invalid age")
    if not record.gender:
        issues.append("Missing/unclear gender")
    if record.ocr_confidence < min_confidence:
        issues.append(f"Low OCR confidence ({record.ocr_confidence:.1f})")
    record.review_needed = bool(issues)
    record.review_issues = "; ".join(issues)
    return record


def parse_voter_record(
    text: str,
    confidence: float,
    source_file: str,
    page_number: int,
    card_number: int,
    min_confidence: float = 35.0,
) -> VoterRecord:
    normalized = normalize_text(text)

    relative_name = ""
    relation_type = ""
    for key, relation in (
        ("father", "Father / पिता"),
        ("husband", "Husband / पति"),
        ("mother", "Mother / माता"),
        ("other", "Other / अन्य"),
    ):
        relative_name = extract_labeled_value(normalized, FIELD_LABELS[key])
        if relative_name:
            relation_type = relation
            break

    record = VoterRecord(
        source_file=source_file,
        page_number=page_number,
        card_number=card_number,
        serial_number=extract_serial_number(normalized),
        epic_id=extract_epic_id(normalized),
        voter_name=extract_labeled_value(normalized, FIELD_LABELS["name"]),
        relative_name=relative_name,
        relation_type=relation_type,
        house_number=extract_labeled_value(normalized, FIELD_LABELS["house"]),
        age=extract_age(normalized),
        gender=extract_gender(normalized),
        ocr_confidence=round(float(confidence), 1),
        raw_ocr_text=normalized,
    )

    return apply_review_flags(record, min_confidence)


def pil_to_bgr(image: Image.Image) -> np.ndarray:
    rgb = np.asarray(image.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def preprocess_for_ocr(image: Image.Image) -> Image.Image:
    """Improve contrast while preserving Devanagari headline strokes."""
    bgr = pil_to_bgr(image)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, None, h=10, templateWindowSize=7, searchWindowSize=21)
    gray = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    threshold = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        41,
        15,
    )
    return Image.fromarray(threshold)


def _iou(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    if x2 <= x1 or y2 <= y1:
        return 0.0
    inter = (x2 - x1) * (y2 - y1)
    union = aw * ah + bw * bh - inter
    return inter / union if union else 0.0


def _dedupe_boxes(boxes: Sequence[tuple[int, int, int, int]]) -> list[tuple[int, int, int, int]]:
    result: list[tuple[int, int, int, int]] = []
    for box in sorted(boxes, key=lambda b: b[2] * b[3], reverse=True):
        if all(_iou(box, kept) < 0.70 for kept in result):
            result.append(box)
    return result


def detect_card_boxes(image: Image.Image, config: OCRConfig) -> list[tuple[int, int, int, int]]:
    """Detect bordered voter cards using multiple contour strategies."""
    bgr = pil_to_bgr(image)
    height, width = bgr.shape[:2]
    top = int(height * config.trim_top_percent)
    bottom = int(height * (1.0 - config.trim_bottom_percent))
    body = bgr[top:bottom, :]
    gray = cv2.cvtColor(body, cv2.COLOR_BGR2GRAY)
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 35, 15)

    # Strengthen both printed borders and text clusters.
    horizontal = cv2.morphologyEx(
        binary,
        cv2.MORPH_OPEN,
        cv2.getStructuringElement(cv2.MORPH_RECT, (max(25, width // 25), 1)),
    )
    vertical = cv2.morphologyEx(
        binary,
        cv2.MORPH_OPEN,
        cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(20, height // 90))),
    )
    lines = cv2.bitwise_or(horizontal, vertical)
    lines = cv2.dilate(lines, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)), iterations=1)

    candidates: list[tuple[int, int, int, int]] = []
    for mask in (lines, cv2.Canny(gray, 50, 160)):
        contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            wr, hr = w / width, h / height
            area_ratio = (w * h) / float(width * height)
            if not (0.19 <= wr <= 0.39):
                continue
            if not (0.045 <= hr <= 0.30):
                continue
            if not (0.009 <= area_ratio <= 0.105):
                continue
            pad_x = max(4, int(w * 0.01))
            pad_y = max(4, int(h * 0.02))
            candidates.append(
                (
                    max(0, x - pad_x),
                    max(0, y + top - pad_y),
                    min(width - x + pad_x, w + 2 * pad_x),
                    min(height - (y + top) + pad_y, h + 2 * pad_y),
                )
            )

    candidates = _dedupe_boxes(candidates)
    # Keep boxes aligned with one of the expected three page columns.
    filtered: list[tuple[int, int, int, int]] = []
    for box in candidates:
        x, y, w, h = box
        center = (x + w / 2) / width
        expected_centers = (1 / 6, 3 / 6, 5 / 6)
        if min(abs(center - c) for c in expected_centers) < 0.18:
            filtered.append(box)

    return sort_boxes_reading_order(filtered)


def sort_boxes_reading_order(boxes: Sequence[tuple[int, int, int, int]]) -> list[tuple[int, int, int, int]]:
    if not boxes:
        return []
    median_h = float(np.median([h for _, _, _, h in boxes]))
    row_tolerance = max(20.0, median_h * 0.35)
    rows: list[list[tuple[int, int, int, int]]] = []
    for box in sorted(boxes, key=lambda b: (b[1], b[0])):
        cy = box[1] + box[3] / 2
        placed = False
        for row in rows:
            row_cy = float(np.mean([b[1] + b[3] / 2 for b in row]))
            if abs(cy - row_cy) <= row_tolerance:
                row.append(box)
                placed = True
                break
        if not placed:
            rows.append([box])
    rows.sort(key=lambda row: min(b[1] for b in row))
    ordered: list[tuple[int, int, int, int]] = []
    for row in rows:
        ordered.extend(sorted(row, key=lambda b: b[0]))
    return ordered


def fallback_column_crops(image: Image.Image, config: OCRConfig) -> list[Image.Image]:
    """Return three page columns when card borders cannot be detected."""
    width, height = image.size
    top = int(height * config.trim_top_percent)
    bottom = int(height * (1.0 - config.trim_bottom_percent))
    margin = int(width * 0.015)
    usable_width = width - 2 * margin
    col_width = usable_width / 3
    crops: list[Image.Image] = []
    for idx in range(3):
        left = int(margin + idx * col_width)
        right = int(margin + (idx + 1) * col_width)
        crops.append(image.crop((left, top, right, bottom)))
    return crops


def ocr_image(image: Image.Image, config: OCRConfig, psm: Optional[int] = None) -> tuple[str, float]:
    prepared = preprocess_for_ocr(image)
    data = pytesseract.image_to_data(
        prepared,
        lang=config.language,
        config=f"--oem 3 --psm {psm or config.psm}",
        output_type=Output.DICT,
    )
    words: list[str] = []
    confidences: list[float] = []
    for word, conf in zip(data["text"], data["conf"]):
        word = word.strip()
        if word:
            words.append(word)
        try:
            numeric = float(conf)
        except (TypeError, ValueError):
            continue
        if numeric >= 0 and word:
            confidences.append(numeric)

    # image_to_string retains line breaks, which are important for label parsing.
    text = pytesseract.image_to_string(
        prepared,
        lang=config.language,
        config=f"--oem 3 --psm {psm or config.psm}",
    )
    confidence = float(np.mean(confidences)) if confidences else 0.0
    return normalize_text(text), confidence


def recover_id_fields_with_english(image: Image.Image) -> tuple[str, str]:
    """Run a lightweight English-only pass to recover Latin EPIC IDs and serials.

    Hindi OCR sometimes interprets Latin EPIC letters as Devanagari glyphs.
    This second pass is only used when the main OCR pass misses the ID.
    """
    prepared = preprocess_for_ocr(image)
    text = pytesseract.image_to_string(prepared, lang="eng", config="--oem 3 --psm 11")
    return extract_epic_id(text), extract_serial_number(text)


def enrich_missing_id_fields(record: VoterRecord, image: Image.Image, min_confidence: float) -> VoterRecord:
    if record.epic_id and record.serial_number:
        return record
    epic_id, serial_number = recover_id_fields_with_english(image)
    if not record.epic_id and epic_id:
        record.epic_id = epic_id
    if serial_number and (not record.serial_number or epic_id):
        record.serial_number = serial_number
    return apply_review_flags(record, min_confidence)


def split_multi_record_text(text: str) -> list[str]:
    """Split OCR from a whole column into likely voter records."""
    normalized = normalize_text(text)
    if not normalized:
        return []

    lines = [line.strip() for line in normalized.splitlines() if line.strip()]
    chunks: list[list[str]] = []
    current: list[str] = []

    def looks_like_start(line: str) -> bool:
        if EPIC_RE.search(line.upper()):
            return True
        if re.match(r"^\d{1,5}\s+[A-Z]{2,4}[0-9OILSBZG]{5,9}\b", line.upper()):
            return True
        return False

    for line in lines:
        if current and looks_like_start(line) and any(
            token in " ".join(current).lower() for token in ("आयु", "age", "लिंग", "gender")
        ):
            chunks.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        chunks.append(current)

    # If starts were not detected, split after completed age/gender lines followed by a name label.
    if len(chunks) == 1:
        chunks = []
        current = []
        completed = False
        for line in lines:
            lower = line.lower()
            is_name_line = any(label.lower() in lower for label in FIELD_LABELS["name"])
            if current and completed and is_name_line:
                chunks.append(current)
                current = [line]
                completed = False
            else:
                current.append(line)
            if any(label.lower() in lower for label in FIELD_LABELS["age"] + FIELD_LABELS["gender"]):
                completed = True
        if current:
            chunks.append(current)

    return ["\n".join(chunk) for chunk in chunks if len(" ".join(chunk)) >= 12]


def render_pdf_pages(pdf_bytes: bytes, config: OCRConfig) -> list[tuple[int, Image.Image, str]]:
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    start = min(max(config.skip_first_pages, 0), len(doc))
    stop = len(doc)
    if config.max_pages is not None:
        stop = min(stop, start + max(0, config.max_pages))
    scale = config.dpi / 72.0
    matrix = fitz.Matrix(scale, scale)
    pages: list[tuple[int, Image.Image, str]] = []
    for index in range(start, stop):
        page = doc[index]
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        native_text = normalize_text(page.get_text("text"))
        pages.append((index + 1, image, native_text))
    doc.close()
    return pages


def load_image_pages(data: bytes, config: OCRConfig) -> list[tuple[int, Image.Image, str]]:
    image = Image.open(io.BytesIO(data))
    frames = [ImageOps.exif_transpose(frame.copy()).convert("RGB") for frame in ImageSequence.Iterator(image)]
    start = min(max(config.skip_first_pages, 0), len(frames))
    stop = len(frames)
    if config.max_pages is not None:
        stop = min(stop, start + max(0, config.max_pages))
    return [(i + 1, frames[i], "") for i in range(start, stop)]


def _native_text_blocks(pdf_bytes: bytes, config: OCRConfig) -> dict[int, list[str]]:
    """Extract native PDF blocks when a PDF already contains usable text."""
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    start = min(max(config.skip_first_pages, 0), len(doc))
    stop = len(doc) if config.max_pages is None else min(len(doc), start + max(0, config.max_pages))
    result: dict[int, list[str]] = {}
    for index in range(start, stop):
        blocks = []
        for block in doc[index].get_text("blocks"):
            block_text = normalize_text(str(block[4]))
            if len(block_text) >= 15:
                blocks.append(block_text)
        result[index + 1] = blocks
    doc.close()
    return result


def _looks_like_voter_text(text: str) -> bool:
    lower = text.lower()
    signals = 0
    if extract_epic_id(text):
        signals += 2
    if any(label.lower() in lower for label in FIELD_LABELS["name"]):
        signals += 1
    if any(label.lower() in lower for label in FIELD_LABELS["age"]):
        signals += 1
    if any(label.lower() in lower for label in FIELD_LABELS["gender"]):
        signals += 1
    return signals >= 2


def process_file_bytes(
    data: bytes,
    filename: str,
    config: Optional[OCRConfig] = None,
    progress_callback: Optional[ProgressCallback] = None,
) -> tuple[list[VoterRecord], int]:
    config = config or OCRConfig()
    suffix = Path(filename).suffix.lower()
    is_pdf = suffix == ".pdf"
    if is_pdf:
        pages = render_pdf_pages(data, config)
        native_blocks = _native_text_blocks(data, config)
    else:
        pages = load_image_pages(data, config)
        native_blocks = {}

    records: list[VoterRecord] = []
    total_pages = len(pages)
    for page_idx, (page_number, image, native_text) in enumerate(pages, start=1):
        if progress_callback:
            progress_callback(page_idx - 1, total_pages, f"Reading {filename} - page {page_number}")

        page_records: list[VoterRecord] = []
        usable_native = [block for block in native_blocks.get(page_number, []) if _looks_like_voter_text(block)]
        if len(usable_native) >= config.min_card_count:
            for card_number, block in enumerate(usable_native, start=1):
                page_records.append(
                    parse_voter_record(
                        block,
                        confidence=100.0,
                        source_file=filename,
                        page_number=page_number,
                        card_number=card_number,
                        min_confidence=config.min_confidence,
                    )
                )
        else:
            boxes = detect_card_boxes(image, config) if config.detect_cards else []
            if len(boxes) >= config.min_card_count:
                for card_number, (x, y, w, h) in enumerate(boxes, start=1):
                    crop = image.crop((x, y, x + w, y + h))
                    text, confidence = ocr_image(crop, config, psm=config.psm)
                    if len(text) >= 8:
                        record = parse_voter_record(
                            text,
                            confidence,
                            filename,
                            page_number,
                            card_number,
                            config.min_confidence,
                        )
                        page_records.append(enrich_missing_id_fields(record, crop, config.min_confidence))
            else:
                card_number = 0
                for column in fallback_column_crops(image, config):
                    text, confidence = ocr_image(column, config, psm=6)
                    chunks = split_multi_record_text(text)
                    if not chunks and text:
                        chunks = [text]
                    for chunk in chunks:
                        card_number += 1
                        page_records.append(
                            parse_voter_record(
                                chunk,
                                confidence,
                                filename,
                                page_number,
                                card_number,
                                config.min_confidence,
                            )
                        )

        # Remove obvious page headers and blank OCR fragments.
        page_records = [
            record
            for record in page_records
            if record.epic_id
            or record.voter_name
            or record.age
            or any(label in record.raw_ocr_text.lower() for label in ("नाम", "name", "आयु", "age"))
        ]
        records.extend(page_records)
        if progress_callback:
            progress_callback(page_idx, total_pages, f"Finished {filename} - page {page_number}")

    return records, total_pages


def deduplicate_records(records: Sequence[VoterRecord]) -> list[VoterRecord]:
    """Preserve every row and flag repeated EPIC IDs for review.

    OCR can accidentally turn two different IDs into the same text. Dropping
    duplicates would therefore risk losing a real voter row.
    """
    epic_counts: dict[str, int] = {}
    for record in records:
        if record.epic_id:
            epic_counts[record.epic_id] = epic_counts.get(record.epic_id, 0) + 1

    output = list(records)
    for record in output:
        if record.epic_id and epic_counts.get(record.epic_id, 0) > 1:
            issue = f"Duplicate EPIC ID in export ({record.epic_id})"
            existing = [part.strip() for part in record.review_issues.split(";") if part.strip()]
            if issue not in existing:
                existing.append(issue)
            record.review_needed = True
            record.review_issues = "; ".join(existing)

    return sorted(output, key=lambda r: (r.source_file.lower(), r.page_number, r.card_number))


def export_to_excel(
    records: Sequence[VoterRecord],
    output_path: Union[str, Path],
    config: Optional[OCRConfig] = None,
    total_pages: int = 0,
) -> Path:
    config = config or OCRConfig()
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    workbook = xlsxwriter.Workbook(str(output), {"constant_memory": True})
    workbook.set_properties(
        {
            "title": "Voter List OCR Export",
            "subject": "Structured voter-list data extracted from PDFs/images",
            "author": "Voter List PDF To Excel - Python OCR Tool",
        }
    )

    header_fmt = workbook.add_format(
        {
            "bold": True,
            "font_color": "#FFFFFF",
            "bg_color": "#1F4E78",
            "border": 1,
            "align": "center",
            "valign": "vcenter",
        }
    )
    text_fmt = workbook.add_format({"valign": "top", "border": 1})
    wrap_fmt = workbook.add_format({"valign": "top", "border": 1, "text_wrap": True})
    number_fmt = workbook.add_format({"valign": "top", "border": 1, "align": "center"})
    review_fmt = workbook.add_format({"bg_color": "#FCE8E6", "font_color": "#9C0006"})
    good_fmt = workbook.add_format({"bg_color": "#E2F0D9", "font_color": "#375623"})
    title_fmt = workbook.add_format({"bold": True, "font_size": 16, "font_color": "#1F4E78"})
    metric_label_fmt = workbook.add_format({"bold": True, "bg_color": "#D9EAF7", "border": 1})
    metric_value_fmt = workbook.add_format({"border": 1})

    columns = [
        ("Source File", "source_file", 24),
        ("Page", "page_number", 8),
        ("Card", "card_number", 8),
        ("Serial Number", "serial_number", 13),
        ("EPIC ID", "epic_id", 15),
        ("Voter Name", "voter_name", 24),
        ("Relative Name", "relative_name", 24),
        ("Relation Type", "relation_type", 17),
        ("House Number", "house_number", 16),
        ("Age", "age", 8),
        ("Gender", "gender", 18),
        ("OCR Confidence", "ocr_confidence", 15),
        ("Review Needed", "review_needed", 14),
        ("Review Issues", "review_issues", 32),
        ("Raw OCR Text", "raw_ocr_text", 55),
    ]

    voters = workbook.add_worksheet("Voters")
    voters.freeze_panes(1, 0)
    voters.set_row(0, 24)
    for col, (title, _field, width) in enumerate(columns):
        voters.write(0, col, title, header_fmt)
        voters.set_column(col, col, width)

    for row, record in enumerate(records, start=1):
        values = asdict(record)
        for col, (_title, field, _width) in enumerate(columns):
            value = values[field]
            fmt = wrap_fmt if field in {"review_issues", "raw_ocr_text"} else text_fmt
            if field in {"page_number", "card_number", "age", "ocr_confidence"}:
                fmt = number_fmt
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            voters.write(row, col, value, fmt)

    last_row = max(1, len(records))
    voters.autofilter(0, 0, last_row, len(columns) - 1)
    voters.conditional_format(1, 12, last_row, 12, {"type": "text", "criteria": "containing", "value": "Yes", "format": review_fmt})
    voters.conditional_format(1, 12, last_row, 12, {"type": "text", "criteria": "containing", "value": "No", "format": good_fmt})

    review_sheet = workbook.add_worksheet("Review Required")
    review_sheet.freeze_panes(1, 0)
    review_sheet.set_row(0, 24)
    for col, (title, _field, width) in enumerate(columns):
        review_sheet.write(0, col, title, header_fmt)
        review_sheet.set_column(col, col, width)
    review_row = 1
    for record in records:
        if not record.review_needed:
            continue
        values = asdict(record)
        for col, (_title, field, _width) in enumerate(columns):
            value = values[field]
            fmt = wrap_fmt if field in {"review_issues", "raw_ocr_text"} else text_fmt
            if field in {"page_number", "card_number", "age", "ocr_confidence"}:
                fmt = number_fmt
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            review_sheet.write(review_row, col, value, fmt)
        review_row += 1
    review_sheet.autofilter(0, 0, max(1, review_row - 1), len(columns) - 1)

    summary = workbook.add_worksheet("Run Summary")
    summary.set_column("A:A", 28)
    summary.set_column("B:B", 42)
    summary.write("A1", "Voter List OCR Run Summary", title_fmt)
    review_count = sum(1 for r in records if r.review_needed)
    unique_files = len({r.source_file for r in records})
    summary_rows = [
        ("Generated rows", len(records)),
        ("Rows requiring review", review_count),
        ("Rows without review flags", len(records) - review_count),
        ("Input files represented", unique_files),
        ("Pages processed", total_pages),
        ("OCR language", config.language),
        ("Render DPI", config.dpi),
        ("Minimum confidence", config.min_confidence),
        ("Card detection enabled", "Yes" if config.detect_cards else "No"),
        ("Important", "OCR is probabilistic. Verify Review Required rows against the source PDF."),
    ]
    for row, (label, value) in enumerate(summary_rows, start=3):
        summary.write(row - 1, 0, label, metric_label_fmt)
        summary.write(row - 1, 1, value, metric_value_fmt)

    workbook.close()
    return output


def process_paths(
    paths: Sequence[Union[str, Path]],
    output: Union[str, Path],
    config: Optional[OCRConfig] = None,
) -> Path:
    config = config or OCRConfig()
    all_records: list[VoterRecord] = []
    total_pages = 0
    for path_like in paths:
        path = Path(path_like)
        records, pages = process_file_bytes(path.read_bytes(), path.name, config)
        all_records.extend(records)
        total_pages += pages
    all_records = deduplicate_records(all_records)
    return export_to_excel(all_records, output, config=config, total_pages=total_pages)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Convert voter-list PDFs/images to Excel using Hindi + English OCR.")
    parser.add_argument("inputs", nargs="+", help="PDF, PNG, JPG, JPEG, or TIFF files")
    parser.add_argument("-o", "--output", default="voter_list_output.xlsx", help="Output Excel file")
    parser.add_argument("--dpi", type=int, default=250, help="PDF rendering DPI (default: 250)")
    parser.add_argument("--language", default="hin+eng", help="Tesseract language string (default: hin+eng)")
    parser.add_argument("--psm", type=int, default=6, help="Tesseract page segmentation mode for cards")
    parser.add_argument("--min-confidence", type=float, default=35.0)
    parser.add_argument("--skip-first-pages", type=int, default=0)
    parser.add_argument("--max-pages", type=int, default=None)
    parser.add_argument("--no-card-detection", action="store_true")
    return parser


def main() -> int:
    parser = build_arg_parser()
    args = parser.parse_args()
    config = OCRConfig(
        dpi=args.dpi,
        language=args.language,
        psm=args.psm,
        min_confidence=args.min_confidence,
        detect_cards=not args.no_card_detection,
        skip_first_pages=args.skip_first_pages,
        max_pages=args.max_pages,
    )
    ok, message = verify_tesseract(config.language)
    if not ok:
        parser.error(message)
    output = process_paths(args.inputs, args.output, config)
    print(f"Excel created: {output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
