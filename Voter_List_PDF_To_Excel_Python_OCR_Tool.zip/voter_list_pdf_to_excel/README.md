# Voter List PDF To Excel - Python OCR Tool

A local desktop app that converts Hindi/English voter-list PDFs and images into a structured Excel workbook.

## Extracted columns

- Source file and page
- Serial number
- EPIC ID
- Voter name
- Relative name and relationship type
- House number
- Age
- Gender
- OCR confidence
- Review status and issues
- Original OCR text

The Excel workbook contains:

1. **Voters** - all extracted rows
2. **Review Required** - rows with missing fields or low OCR confidence
3. **Run Summary** - totals and OCR settings

## Fast start on macOS

1. Extract the ZIP.
2. Open the extracted folder.
3. Double-click `Voter_OCR_Mac.command`.
4. If macOS blocks it, right-click it, choose **Open**, and confirm.

Terminal method:

```bash
chmod +x setup_mac.sh run_mac.sh Voter_OCR_Mac.command
./setup_mac.sh
```

Later, start the app with:

```bash
./run_mac.sh
```

The app runs locally. Your voter-list PDF is not uploaded to an external server.

## Windows

1. Install Python 3.
2. Install Tesseract OCR with Hindi language data and add Tesseract to PATH.
3. Double-click `setup_windows.bat`.
4. Later, use `run_windows.bat`.

## Command-line use

```bash
python voter_ocr.py voter-list.pdf -o output.xlsx
```

Useful options:

```bash
python voter_ocr.py voter-list.pdf -o output.xlsx --dpi 300 --language hin+eng --skip-first-pages 1
```

For a quick test on five pages:

```bash
python voter_ocr.py voter-list.pdf -o test.xlsx --max-pages 5
```

## Recommended workflow

1. Test the first 3-5 voter pages.
2. Use 250 DPI initially; try 300 DPI for unclear scans.
3. Keep `hin+eng` enabled.
4. Open the **Review Required** sheet and compare flagged rows with the PDF.
5. Process the full PDF after the sample looks correct.

## Accuracy notes

OCR is probabilistic. Scanned voter rolls vary in layout, image quality, borders, fonts, and compression. The tool keeps raw OCR text and flags uncertain rows instead of silently accepting them.
