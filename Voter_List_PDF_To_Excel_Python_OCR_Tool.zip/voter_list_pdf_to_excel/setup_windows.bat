@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python 3 was not found. Install Python 3 and enable "Add Python to PATH".
  pause
  exit /b 1
)

where tesseract >nul 2>nul
if errorlevel 1 (
  echo Tesseract OCR was not found in PATH.
  echo Install Tesseract with Hindi language data, add its folder to PATH, then run this file again.
  pause
  exit /b 1
)

python -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python gui.py
endlocal
