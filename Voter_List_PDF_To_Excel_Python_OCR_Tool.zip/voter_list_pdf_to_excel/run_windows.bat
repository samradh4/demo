@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  call setup_windows.bat
  exit /b %errorlevel%
)
call .venv\Scripts\activate.bat
python gui.py
endlocal
