#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  exec ./setup_mac.sh
fi
source .venv/bin/activate
python gui.py
