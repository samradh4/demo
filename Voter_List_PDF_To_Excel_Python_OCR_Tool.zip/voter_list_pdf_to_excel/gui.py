#!/usr/bin/env python3
"""Native desktop GUI for the voter-list PDF/image OCR converter."""

from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from typing import Optional, Tuple
from tkinter import filedialog, messagebox, ttk

from voter_ocr import OCRConfig, deduplicate_records, export_to_excel, process_file_bytes, verify_tesseract

SUPPORTED_TYPES = [
    ("Voter lists", "*.pdf *.png *.jpg *.jpeg *.tif *.tiff"),
    ("PDF files", "*.pdf"),
    ("Image files", "*.png *.jpg *.jpeg *.tif *.tiff"),
    ("All files", "*.*"),
]


class VoterOCRApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Voter List PDF To Excel - Python OCR Tool")
        self.geometry("980x690")
        self.minsize(860, 610)
        self.files: list[Path] = []
        self.worker_queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self.worker: Optional[threading.Thread] = None
        self.last_output: Optional[Path] = None

        self._build_styles()
        self._build_ui()
        self._check_tesseract()
        self.after(120, self._poll_worker_queue)

    def _build_styles(self) -> None:
        style = ttk.Style(self)
        available = style.theme_names()
        if "clam" in available:
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Arial", 20, "bold"))
        style.configure("Subtitle.TLabel", font=("Arial", 10))
        style.configure("Section.TLabelframe.Label", font=("Arial", 11, "bold"))
        style.configure("Primary.TButton", font=("Arial", 11, "bold"), padding=(14, 9))
        style.configure("Action.TButton", padding=(10, 7))

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=18)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Voter List PDF To Excel", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Hindi + English OCR with EPIC ID, name, relative, house number, age, gender, confidence, and review flags.",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(2, 14))

        self.tesseract_status = ttk.Label(outer, text="Checking Tesseract OCR...")
        self.tesseract_status.pack(anchor="w", pady=(0, 10))

        main = ttk.Panedwindow(outer, orient="horizontal")
        main.pack(fill="both", expand=True)

        left = ttk.Labelframe(main, text="1. Select voter-list files", style="Section.TLabelframe", padding=10)
        right = ttk.Labelframe(main, text="2. OCR settings", style="Section.TLabelframe", padding=12)
        main.add(left, weight=3)
        main.add(right, weight=2)

        list_frame = ttk.Frame(left)
        list_frame.pack(fill="both", expand=True)
        self.file_list = tk.Listbox(list_frame, selectmode="extended", activestyle="dotbox")
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.file_list.yview)
        self.file_list.configure(yscrollcommand=scrollbar.set)
        self.file_list.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        file_buttons = ttk.Frame(left)
        file_buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(file_buttons, text="Add Files", command=self._add_files, style="Action.TButton").pack(side="left")
        ttk.Button(file_buttons, text="Remove Selected", command=self._remove_selected, style="Action.TButton").pack(side="left", padx=8)
        ttk.Button(file_buttons, text="Clear", command=self._clear_files, style="Action.TButton").pack(side="left")

        self.dpi_var = tk.IntVar(value=250)
        self.language_var = tk.StringVar(value="hin+eng")
        self.psm_var = tk.IntVar(value=6)
        self.confidence_var = tk.DoubleVar(value=35.0)
        self.detect_cards_var = tk.BooleanVar(value=True)
        self.skip_pages_var = tk.IntVar(value=0)
        self.limit_pages_var = tk.BooleanVar(value=False)
        self.max_pages_var = tk.IntVar(value=5)

        settings = [
            ("PDF render quality", self._combo(right, self.dpi_var, [150, 200, 250, 300, 350])),
            ("OCR language", ttk.Entry(right, textvariable=self.language_var)),
            ("Tesseract PSM", self._combo(right, self.psm_var, [6, 11, 12, 4])),
            ("Review below confidence", ttk.Spinbox(right, from_=0, to=90, increment=1, textvariable=self.confidence_var)),
            ("Skip first pages", ttk.Spinbox(right, from_=0, to=100, increment=1, textvariable=self.skip_pages_var)),
        ]
        for row, (label, widget) in enumerate(settings):
            ttk.Label(right, text=label).grid(row=row, column=0, sticky="w", pady=6)
            widget.grid(row=row, column=1, sticky="ew", padx=(12, 0), pady=6)

        ttk.Checkbutton(right, text="Detect individual voter cards", variable=self.detect_cards_var).grid(
            row=5, column=0, columnspan=2, sticky="w", pady=(8, 4)
        )
        ttk.Checkbutton(right, text="Limit pages while testing", variable=self.limit_pages_var, command=self._toggle_page_limit).grid(
            row=6, column=0, columnspan=2, sticky="w", pady=4
        )
        ttk.Label(right, text="Maximum pages per file").grid(row=7, column=0, sticky="w", pady=6)
        self.max_pages_spin = ttk.Spinbox(right, from_=1, to=1000, increment=1, textvariable=self.max_pages_var, state="disabled")
        self.max_pages_spin.grid(row=7, column=1, sticky="ew", padx=(12, 0), pady=6)
        right.columnconfigure(1, weight=1)

        output_frame = ttk.Labelframe(outer, text="3. Excel output", style="Section.TLabelframe", padding=10)
        output_frame.pack(fill="x", pady=(14, 0))
        self.output_var = tk.StringVar(value=str(Path.home() / "Desktop" / "voter_list_output.xlsx"))
        output_entry = ttk.Entry(output_frame, textvariable=self.output_var)
        output_entry.pack(side="left", fill="x", expand=True)
        ttk.Button(output_frame, text="Choose Location", command=self._choose_output, style="Action.TButton").pack(side="left", padx=(10, 0))

        progress_frame = ttk.Frame(outer)
        progress_frame.pack(fill="x", pady=(14, 0))
        self.progress = ttk.Progressbar(progress_frame, mode="determinate", maximum=100)
        self.progress.pack(fill="x")
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w", pady=(5, 0))

        action_frame = ttk.Frame(outer)
        action_frame.pack(fill="x", pady=(14, 0))
        self.convert_button = ttk.Button(action_frame, text="Convert To Excel", command=self._start_conversion, style="Primary.TButton")
        self.convert_button.pack(side="left", fill="x", expand=True)
        self.open_button = ttk.Button(action_frame, text="Open Output Folder", command=self._open_output_folder, style="Action.TButton", state="disabled")
        self.open_button.pack(side="left", padx=(10, 0))

        ttk.Label(
            outer,
            text="Important: OCR can make mistakes. Verify the 'Review Required' sheet against the original PDF.",
        ).pack(anchor="w", pady=(10, 0))

    @staticmethod
    def _combo(parent: tk.Widget, variable: tk.Variable, values: list[int]) -> ttk.Combobox:
        return ttk.Combobox(parent, textvariable=variable, values=values, state="readonly")

    def _check_tesseract(self) -> None:
        ok, message = verify_tesseract(self.language_var.get().strip())
        if ok:
            self.tesseract_status.configure(text=f"Tesseract ready: {message}", foreground="#1b6e1b")
            self.convert_button.configure(state="normal")
        else:
            self.tesseract_status.configure(text=message, foreground="#a40000")
            self.convert_button.configure(state="disabled")

    def _toggle_page_limit(self) -> None:
        self.max_pages_spin.configure(state="normal" if self.limit_pages_var.get() else "disabled")

    def _add_files(self) -> None:
        selected = filedialog.askopenfilenames(title="Select voter-list PDFs or images", filetypes=SUPPORTED_TYPES)
        existing = {str(path.resolve()) for path in self.files}
        for filename in selected:
            path = Path(filename)
            key = str(path.resolve())
            if key not in existing:
                self.files.append(path)
                existing.add(key)
        self._refresh_file_list()

    def _remove_selected(self) -> None:
        indices = list(self.file_list.curselection())
        for index in reversed(indices):
            del self.files[index]
        self._refresh_file_list()

    def _clear_files(self) -> None:
        self.files.clear()
        self._refresh_file_list()

    def _refresh_file_list(self) -> None:
        self.file_list.delete(0, tk.END)
        for path in self.files:
            size_mb = path.stat().st_size / (1024 * 1024) if path.exists() else 0
            self.file_list.insert(tk.END, f"{path.name}  ({size_mb:.1f} MB)")
        self.status_var.set(f"{len(self.files)} file(s) selected")

    def _choose_output(self) -> None:
        selected = filedialog.asksaveasfilename(
            title="Save Excel file",
            defaultextension=".xlsx",
            initialfile="voter_list_output.xlsx",
            filetypes=[("Excel workbook", "*.xlsx")],
        )
        if selected:
            self.output_var.set(selected)

    def _validate_inputs(self) -> Optional[Tuple[OCRConfig, Path]]:
        if not self.files:
            messagebox.showwarning("No files", "Add at least one PDF or image first.")
            return None
        missing = [str(path) for path in self.files if not path.exists()]
        if missing:
            messagebox.showerror("Missing files", "Some selected files no longer exist:\n\n" + "\n".join(missing[:10]))
            return None
        language = self.language_var.get().strip() or "hin+eng"
        ok, message = verify_tesseract(language)
        if not ok:
            messagebox.showerror("Tesseract not ready", message)
            return None
        output = Path(self.output_var.get().strip()).expanduser()
        if output.suffix.lower() != ".xlsx":
            output = output.with_suffix(".xlsx")
            self.output_var.set(str(output))
        try:
            output.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("Output error", f"Cannot create the output folder:\n{exc}")
            return None
        config = OCRConfig(
            dpi=int(self.dpi_var.get()),
            language=language,
            psm=int(self.psm_var.get()),
            min_confidence=float(self.confidence_var.get()),
            detect_cards=bool(self.detect_cards_var.get()),
            skip_first_pages=int(self.skip_pages_var.get()),
            max_pages=int(self.max_pages_var.get()) if self.limit_pages_var.get() else None,
        )
        return config, output

    def _start_conversion(self) -> None:
        validated = self._validate_inputs()
        if validated is None:
            return
        config, output = validated
        self.convert_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.progress["value"] = 0
        self.status_var.set("Starting OCR...")
        selected_files = list(self.files)
        self.worker = threading.Thread(target=self._convert_worker, args=(config, output, selected_files), daemon=True)
        self.worker.start()

    def _convert_worker(self, config: OCRConfig, output: Path, selected_files: list[Path]) -> None:
        all_records = []
        total_pages = 0
        file_count = len(selected_files)
        try:
            for file_index, path in enumerate(selected_files):
                data = path.read_bytes()

                def report(done: int, page_total: int, message: str) -> None:
                    within = done / max(page_total, 1)
                    overall = (file_index + within) / max(file_count, 1)
                    self.worker_queue.put(("progress", (overall * 100, message)))

                records, pages = process_file_bytes(data, path.name, config, report)
                all_records.extend(records)
                total_pages += pages
            all_records = deduplicate_records(all_records)
            self.worker_queue.put(("progress", (97.0, "Creating Excel workbook...")))
            export_to_excel(all_records, output, config=config, total_pages=total_pages)
            review_count = sum(1 for record in all_records if record.review_needed)
            self.worker_queue.put(("done", (output, len(all_records), review_count, total_pages)))
        except Exception as exc:
            self.worker_queue.put(("error", exc))

    def _poll_worker_queue(self) -> None:
        try:
            while True:
                event, payload = self.worker_queue.get_nowait()
                if event == "progress":
                    percent, message = payload  # type: ignore[misc]
                    self.progress["value"] = float(percent)
                    self.status_var.set(str(message))
                elif event == "done":
                    output, rows, review_count, pages = payload  # type: ignore[misc]
                    self.last_output = Path(output)
                    self.progress["value"] = 100
                    self.status_var.set(f"Finished: {rows} rows from {pages} page(s); {review_count} row(s) require review.")
                    self.convert_button.configure(state="normal")
                    self.open_button.configure(state="normal")
                    messagebox.showinfo(
                        "Excel created",
                        f"Saved to:\n{output}\n\nRows: {rows}\nReview required: {review_count}\nPages: {pages}",
                    )
                elif event == "error":
                    self.convert_button.configure(state="normal")
                    self.progress["value"] = 0
                    self.status_var.set("Conversion failed")
                    messagebox.showerror("Conversion failed", str(payload))
        except queue.Empty:
            pass
        self.after(120, self._poll_worker_queue)

    def _open_output_folder(self) -> None:
        if self.last_output is None:
            return
        folder = self.last_output.parent
        try:
            if sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            elif os.name == "nt":
                os.startfile(str(folder))  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except OSError as exc:
            messagebox.showerror("Open folder failed", str(exc))


def main() -> int:
    app = VoterOCRApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
