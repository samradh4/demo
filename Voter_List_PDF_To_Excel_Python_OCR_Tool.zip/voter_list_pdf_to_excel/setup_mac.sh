#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install Python 3, then run this file again."
  exit 1
fi

if ! python3 - <<'PY' >/dev/null 2>&1
import tkinter
PY
then
  echo "Your Python installation does not include Tkinter."
  echo "Install Python from python.org or install the matching python-tk package, then try again."
  exit 1
fi

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew is required to install Tesseract automatically."
  echo "Install Homebrew from its official website, then run this file again."
  exit 1
fi

if ! command -v tesseract >/dev/null 2>&1; then
  brew install tesseract
fi

if ! tesseract --list-langs 2>/dev/null | grep -qx "hin"; then
  brew install tesseract-lang
fi

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python gui.py
